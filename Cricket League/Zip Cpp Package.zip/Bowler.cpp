#include <iostream>
#include <string>
#include "Bowler.h"
using namespace std;

Bowler::Bowler(){
    runs=0;
    wickets=0;
    balls=0;
    name="";
    introduced=false;
}
