#include <iostream>
#include <string>
#include "Ptable.h"
using namespace std;

PTable::PTable(){
    teamname="";
    matches=0;
    won=0;
    lost=0;
    draw=0;
    points=0;
}
