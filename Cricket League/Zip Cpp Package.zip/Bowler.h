#ifndef BOWLER_H_INCLUDED
#define BOWLER_H_INCLUDED

#include <iostream>
#include <string>
using namespace std;
class Bowler{
public:
    string name;
    int runs,wickets,balls;
    bool introduced;
    Bowler();
};

#endif // BOWLER_H_INCLUDED
