#include <iostream>
#include <string>
#include "Team.h"
using namespace std;

Team::Team(){
    runs=0;
    balls=0;
    wickets=0;
    teamname="";
}
