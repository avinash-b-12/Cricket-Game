#include <iostream>
#include <string>
#include "Batsman.h"
using namespace std;

Batsman::Batsman(){
    runs=0;
    balls=0;
    name="";
    captain=false;
    didbat=false;
    status=true;
    introduced=false;
}
