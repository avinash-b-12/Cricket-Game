#ifndef TIMELINE_H_INCLUDED
#define TIMELINE_H_INCLUDED
#include <iostream>
#include <string>
using namespace std;

class Timeline{
public:
    char timeline[6];
    int limit;
    Timeline();
};

#endif // TIMELINE_H_INCLUDED
